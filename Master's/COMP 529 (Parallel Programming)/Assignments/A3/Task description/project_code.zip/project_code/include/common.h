// common.h
// Created: 03-12-2019
// Author: Najeeb Ahmad

#include <iostream>
#include <string>
#include <cstring>
#include <time.h>
#include <math.h>

#include <sys/time.h>

#ifndef val_type
#define val_type double
#endif

#ifndef ind_type
#define ind_type int
#endif

#ifndef sz_type
#define sz_type int
#endif

